from flask import Flask, render_template, request, redirect, url_for, session, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import secrets
import os
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', secrets.token_hex(32))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shop.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=1)

db = SQLAlchemy(app)

Talisman(
    app,
    force_https=True,
    strict_transport_security=True,
    session_cookie_secure=True,
    session_cookie_http_only=True,
    content_security_policy={
        'default-src': "'none'",
        'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        'style-src': ["'self'", "'unsafe-inline'"],
        'img-src': ["'self'", "data:"],
        'font-src': ["'self'"],
        'connect-src': ["'self'"],
        'form-action': ["'self'"],
        'frame-ancestors': ["'none'"],
    },
    referrer_policy='no-referrer',
    feature_policy={
        'geolocation': "'none'",
        'camera': "'none'",
        'microphone': "'none'",
        'payment': "'none'"
    }
)

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://",
    strategy="fixed-window",
    headers_enabled=True
)

login_limiter = limiter.limit("5 per minute")
register_limiter = limiter.limit("3 per hour")

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    access_key = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Shop(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    shop_id = db.Column(db.Integer, db.ForeignKey('shop.id'), nullable=False)
    reviewer = db.Column(db.String(80))
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AnonymousFeedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    feedback = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

def validate_access_key(key):
    return len(key) >= 16

def check_password_complexity(password):
    if len(password) < 12:
        return False
    return (any(c.isupper() for c in password) and any(c.islower() for c in password) and any(c.isdigit() for c in password) and any(not c.isalnum() for c in password))

def generate_csrf_token():
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']

app.jinja_env.globals['csrf_token'] = generate_csrf_token

@app.before_request
def security_checks():
    if request.method == "POST":
        token = session.get('_csrf_token')
        if not token or token != request.form.get('_csrf_token'):
            abort(403, description="CSRF token invalid")

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'no-referrer'
    return response

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
@register_limiter
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        access_key = request.form['access_key']

        if not validate_access_key(access_key):
            return render_template('register.html', error="Invalid access key")
        if not check_password_complexity(password):
            return render_template('register.html', error="Mật khẩu phải có ít nhất 12 ký tự, gồm chữ hoa, thường, số và ký tự đặc biệt")
        if User.query.filter_by(username=username).first():
            return render_template('register.html', error="Username đã tồn tại")

        new_user = User(username=username, access_key=generate_password_hash(access_key))
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
@login_limiter
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        access_key = request.form['access_key']

        user = User.query.filter_by(username=username).first()
        if not user or not user.check_password(password) or not check_password_hash(user.access_key, access_key):
            return render_template('login.html', error="Thông tin đăng nhập không chính xác")
        session['user_id'] = user.id
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = User.query.get(session['user_id'])
    shops = Shop.query.filter_by(user_id=user.id).all()
    return render_template('dashboard.html', user=user, shops=shops)

@app.route('/create_shop', methods=['GET', 'POST'])
def create_shop():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        new_shop = Shop(user_id=session['user_id'], name=name, description=description)
        db.session.add(new_shop)
        db.session.commit()
        return redirect(url_for('dashboard'))
    return render_template('create_shop.html')

@app.route('/shop/<int:shop_id>')
def shop_details(shop_id):
    shop = Shop.query.get_or_404(shop_id)
    reviews = Review.query.filter_by(shop_id=shop.id).all()
    return render_template('shop.html', shop=shop, reviews=reviews)

@app.route('/chatroom', methods=['GET', 'POST'])
def chatroom():
    if request.method == 'POST':
        message = request.form['message']
        user_id = session.get('user_id')
        if user_id:
            msg = ChatMessage(user_id=user_id, message=message)
            db.session.add(msg)
            db.session.commit()
        return redirect(url_for('chatroom'))
    messages = ChatMessage.query.order_by(ChatMessage.created_at.asc()).all()
    return render_template('chatroom.html', messages=messages)

@app.route('/review/<int:shop_id>', methods=['GET', 'POST'])
def review(shop_id):
    shop = Shop.query.get_or_404(shop_id)
    if request.method == 'POST':
        reviewer = request.form['reviewer']
        rating = int(request.form['rating'])
        comment = request.form['comment']
        new_review = Review(shop_id=shop.id, reviewer=reviewer, rating=rating, comment=comment)
        db.session.add(new_review)
        db.session.commit()
        return redirect(url_for('shop_details', shop_id=shop.id))
    return render_template('review.html', shop=shop)

@app.route('/anonymous', methods=['GET', 'POST'])
def anonymous():
    if request.method == 'POST':
        feedback = request.form['feedback']
        new_feedback = AnonymousFeedback(feedback=feedback)
        db.session.add(new_feedback)
        db.session.commit()
        return redirect(url_for('anonymous'))
    feedbacks = AnonymousFeedback.query.order_by(AnonymousFeedback.created_at.desc()).all()
    return render_template('anonymous.html', feedbacks=feedbacks)

@app.cli.command('initdb')
def initdb_command():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin', access_key=generate_password_hash('your_admin_access_key'))
        admin.set_password('your_admin_password')
        db.session.add(admin)
        db.session.commit()
    print("Database initialized.")

if __name__ == '__main__':
    app.run(ssl_context='adhoc', host='0.0.0.0', port=5000, debug=False)